package main

import (
	"net/http"
	"regexp"

	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
)

type Message struct {
	Message string `json:"message"`
}

type Call struct {
	To_DID        string `json:"to_did"`
	From_DID      string `json:"from_did"`
	Tx_DID        string `json:"tx_did"`
	Human_audio   string `json:"human_audio"`
	Vm_detect     bool   `json:"vm_detect"`
	Vm_drop       bool   `json:"vm_drop"`
	Vm_audio      string `json:"vm_audio"`
	Compaign_type int    `json:"compaign_type"`
	Tx_DTMF       int    `json:"tx_dtmf"`
	DND_DTMP      int    `json:"dnd_dtmp"`
}

func main() {
	// Echo instance
	e := echo.New()

	// Middleware
	e.Use(middleware.Logger())
	e.Use(middleware.Recover())
	// Routes

	e.POST("/call", callapi)

	e.Logger.Fatal(e.Start(":8080"))

}
func callapi(c echo.Context) error {

	u := new(Call)
	if err := c.Bind(u); err != nil {
		return err
	}
	valid_Tx := IsUSNumber(u.Tx_DID)
	valid_To := IsUSNumber(u.To_DID)
	valid_from := IsUSNumber(u.From_DID)
	valid_Haudio, _ := regexp.MatchString(".mp", u.Human_audio)
	valid_Vaudio, _ := regexp.MatchString(".mp", u.Vm_audio)
	if (u.DND_DTMP > 0 && u.DND_DTMP <= 9) && (u.Tx_DTMF > 0 && u.Tx_DTMF <= 9) && (u.Tx_DTMF > 0 && u.Tx_DTMF <= 9) && (valid_Haudio) && (valid_Vaudio) && (valid_from) && (valid_To) && (valid_Tx) == true {
		return c.JSON(http.StatusCreated, u)
	}
	return c.JSON(http.StatusNotFound, Message{"Please Enter Correct Data Formate"})
}
func IsUSNumber(number string) bool {
	match, err := regexp.MatchString("^(?:(?:\\+?1\\s*(?:[.-]\\s*)?)?(?:\\(\\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\\s*\\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\\s*(?:[.-]\\s*)?)([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\\s*(?:[.-]\\s*)?([0-9]{4})(?:\\s*(?:#|x\\.?|ext\\.?|extension)\\s*(\\d+))?$", number)
	if err != nil {
		return false
	}

	return match
}
